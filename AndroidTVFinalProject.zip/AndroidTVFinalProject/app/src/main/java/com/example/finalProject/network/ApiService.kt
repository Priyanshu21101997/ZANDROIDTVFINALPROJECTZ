package com.example.finalProject.network

import com.example.finalProject.models.Movies
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {

    @GET("movie/top_rated")
    fun getTopRatedMovies(@Query("api_key") api_key:String): Call<Movies>

    @GET("movie/popular")
    fun getPopularMovies(@Query("api_key") api_key:String): Call<Movies>

}