package com.example.finalProject.database

import android.text.TextUtils
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import com.example.finalProject.models.Results
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName

@Entity(tableName = "movies_table")
data class MoviesEntity(

    @PrimaryKey(autoGenerate = true)  var movieId : Int? = null,
    var id:Int? = null,
    var result : Results? = null
){
}


class RequestConverter {
    @TypeConverter
    fun stringToOutboxItem(string: String): Results? {
        if (TextUtils.isEmpty(string))
            return null
        return Gson().fromJson(string, Results::class.java)
    }

    @TypeConverter
     fun outboxItemToString(result: Results?): String {
        return Gson().toJson(result)
    }
}