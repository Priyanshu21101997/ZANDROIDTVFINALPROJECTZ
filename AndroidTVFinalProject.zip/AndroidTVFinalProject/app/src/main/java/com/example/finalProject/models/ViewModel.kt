package com.example.finalProject.models

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.finalProject.VideoDetailsFragment
import com.example.finalProject.database.MoviesDatabase
import com.example.finalProject.database.MoviesEntity
import com.example.finalProject.network.ApiService
import com.example.finalProject.network.RetroInstance
import com.example.finalProject.repository.MoviesRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ViewModel(application: Application): AndroidViewModel(application) {

    private val TAG = "ViewModel"
    var topRatedMoviesEntityLiveData: MutableLiveData<Movies>
    var popularMoviesEntityLiveData: MutableLiveData<Movies>
    private val repository : MoviesRepository
    var readFavouriteMoviesEntity : LiveData<List<MoviesEntity>>
    var count:Int? = -1




    init {
        topRatedMoviesEntityLiveData = MutableLiveData<Movies>()
        popularMoviesEntityLiveData = MutableLiveData<Movies>()
        val moviesDao = MoviesDatabase.getDatabase(application).moviesDao()
        repository = MoviesRepository(moviesDao)
        readFavouriteMoviesEntity = repository.readFavouriteMoviesEntity
    }

    fun makeApiCall() {
        val apiService = RetroInstance.getRetroClient()?.create(ApiService::class.java)
        val getTopRatedMoviesEntity: Call<Movies> =
            apiService!!.getTopRatedMovies("e807e46843c45d1ac8631a914207e53e")

        val getPopularMoviesEntity: Call<Movies> =
            apiService!!.getPopularMovies("e807e46843c45d1ac8631a914207e53e")

        getJsonResponse(getTopRatedMoviesEntity,0)
        getJsonResponse(getPopularMoviesEntity,1)

    }

    private fun getJsonResponse(getTopRatedMoviesEntity: Call<Movies>, identifier:Int) {
        getTopRatedMoviesEntity.enqueue(object : Callback<Movies> {
            override fun onResponse(
                call: Call<Movies>,
                response: Response<Movies>) {

                val responses = response.body()
                if(responses!=null) {
                    if(identifier==0)
                        topRatedMoviesEntityLiveData!!.value=responses!!
                    else{
                        popularMoviesEntityLiveData!!.value = responses!!
                    }
                }
            }

            override fun onFailure(call: Call<Movies>, t: Throwable) {
                Log.d(TAG, "${t.message}")
            }
        })
    }

    fun getTopRatedMoviesMutableLiveData():MutableLiveData<Movies>?{
        return topRatedMoviesEntityLiveData
    }

    fun getPopularMoviesMutableLiveData():MutableLiveData<Movies>?{
        return popularMoviesEntityLiveData
    }

    fun addMovieToFavourites(movie: MoviesEntity){
        viewModelScope.launch(Dispatchers.IO) {
            repository.addMovieToFavourites(movie)
        }
    }

    fun getFavouriteMovies():LiveData<List<MoviesEntity>>{
        return readFavouriteMoviesEntity
    }






}