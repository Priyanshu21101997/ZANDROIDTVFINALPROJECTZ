package com.example.finalProject.repository

import androidx.lifecycle.LiveData
import com.example.finalProject.database.MoviesDao
import com.example.finalProject.database.MoviesEntity

class MoviesRepository(val moviesDao: MoviesDao) {

    val readFavouriteMoviesEntity : LiveData<List<MoviesEntity>> = moviesDao.readFavouriteMovies()

    suspend fun addMovieToFavourites(movie:MoviesEntity){
        moviesDao.addMovieToFavourites(movie)
    }

    suspend fun checkAlreadyFavourite(custom_id:Int):Int{
        return moviesDao.checkAlreadyFavourite(custom_id )
    }
}